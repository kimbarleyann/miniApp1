// Kimberly Nguyen
// CWID: 890337231

// Mini-App #1


package edu.fullerton.ecs.cpsc411.mini_app1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.text.DecimalFormat;
import java.util.Locale;


public class MainActivity extends AppCompatActivity {

    EditText input1, input2;

    private TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = (Button) findViewById(R.id.calculateButton);
        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                input1 = (EditText) findViewById(R.id.Mbps);
                input2 = (EditText) findViewById(R.id.MiB);


                int num1 = Integer.parseInt(input1.getText().toString());
                int num2 = Integer.parseInt(input2.getText().toString());
                double result = ((num2 * 8.388608 ) / num1);/// 10;
                // https://stackoverflow.com/questions/5766318/converting-double-to-string
                String result2 = new Double(result).toString();

                // https://stackoverflow.com/questions/24981607/rounding-to-one-decimal-place
                // https://stackoverflow.com/questions/38929085/how-do-i-format-a-double-into-a-string-with-only-two-decimal-places
                String result3 = String.format(Locale.US, "%.1f",result);

                TextView tvResult = (TextView) findViewById(R.id.transferTimeValue);
                //String.format("%.1f", result2);
                tvResult.setText("" +result3);
            }
        });

//        tvResult.addTextChangedListener(new TextWatcher() {
//            @Override
//            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//
//
//            }
//
//            @Override
//            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//
//            }
//
//            @Override
//            public void afterTextChanged(Editable editable) {
//
//            }
//        });




    }
}

// Resources Used:
// DrBFraser on Youtube, https://www.youtube.com/watch?v=aE5f1tV5nU4


